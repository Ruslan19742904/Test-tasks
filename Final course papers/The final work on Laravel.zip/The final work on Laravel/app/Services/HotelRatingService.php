<?php
namespace App\Services;

use App\Models\Hotel;

class HotelRatingService
{
    public function updateRating(Hotel $hotel): void
    {
        // Пересчет среднего рейтинга отеля на основе активных отзывов
        $averageRating = $hotel->feedbacks()
            ->where('is_active', true)
            ->avg('rating');

        $hotel->update([
            'rating' => $averageRating ? round($averageRating, 1) : 0
        ]);
    }
}