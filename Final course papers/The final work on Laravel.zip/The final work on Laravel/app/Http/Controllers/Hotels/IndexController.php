<?php

namespace App\Http\Controllers\Hotels;

use App\Http\Controllers\Controller;
use App\Models\Facility;
use App\Models\Hotel;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;

class IndexController extends Controller
{
    const FILTERS_FORMAT = [
        'filtersByIn' => [
            'id',
            'facilityId', 
            'roomFacilityId',
        ],
        'filtersByLike' => [],
    ];

    const DICTIONARIES_FORMAT = [
        'id' => 'hotel',
        'facilityId' => 'facility',
        'roomFacilityId' => 'roomFacility',
    ];

    // Время кеширования в секундах (5 минут)
    const CACHE_TTL = 300;

    public function __invoke(Request $request)
    {
        // Проверка прав для админ-панели
        $managerHotelIds = $this->getManagerHotelIds();

        // Получаем данные для фильтрации
        $helper = (new HelperController());
        $helper->setIndexData($request);
        $indexData = $helper->indexData;

        // Предзагружаем данные для фильтров
        $this->preloadFilterData($indexData);

        // Основной запрос с оптимизацией
        $hotelsBuilder = $this->buildBaseQuery($managerHotelIds ?? null);
        
        // Применяем фильтры
        $this->applyFilters($hotelsBuilder, $indexData);

        // Получаем данные для фильтров с кешированием
        $filterData = $this->getFilterDataWithCache($hotelsBuilder, $helper);
        
        // Обновляем indexData данными из кеша
        $indexData = array_merge($indexData, $filterData);

        // Итоговый запрос с пагинацией
        $hotels = $this->getFinalResults($hotelsBuilder, $helper);

        return view('hotels.index', compact('hotels', 'indexData'));
    }

    private function getManagerHotelIds(): ?array
    {
        if (!isAdminPanel()) {
            return null;
        }

        $this->authorize('viewAny', Hotel::class);

        if (isManager(auth()->user())) {
            return auth()->user()->hotels->pluck('id')->toArray();
        }

        return null;
    }

    private function preloadFilterData(array &$indexData): void
    {
        // Кешируем запросы для выбранных элементов
        $cacheKeys = [];
        
        if (isset($indexData['filterByHotelId'])) {
            $cacheKeys['hotel'] = 'hotel_' . $indexData['filterByHotelId'];
        }
        
        if (isset($indexData['selectedFacility']['ids'])) {
            $cacheKeys['facilities'] = 'facilities_' . implode('_', $indexData['selectedFacility']['ids']);
        }
        
        if (isset($indexData['selectedRoomFacility']['ids'])) {
            $cacheKeys['room_facilities'] = 'room_facilities_' . implode('_', $indexData['selectedRoomFacility']['ids']);
        }

        foreach ($cacheKeys as $type => $key) {
            $data = Cache::remember($key, self::CACHE_TTL, function () use ($type, $indexData) {
                return $this->fetchFilterData($type, $indexData);
            });
            
            $indexData = array_merge($indexData, $data);
        }
    }

    private function fetchFilterData(string $type, array $indexData): array
    {
        switch ($type) {
            case 'hotel':
                $hotel = Hotel::select('id', 'name')
                    ->where('id', $indexData['filterByHotelId'])
                    ->first();
                    
                return [
                    'selectedHotel' => [
                        'id' => $hotel->id ?? null,
                        'name' => $hotel->name ?? null,
                    ]
                ];

            case 'facilities':
                $facilities = Facility::select('id', 'name')
                    ->whereIn('id', $indexData['selectedFacility']['ids'])
                    ->get()
                    ->map(function($facility) {
                        return [
                            'id' => $facility->id,
                            'name' => $facility->name,
                        ];
                    })
                    ->toArray();
                    
                return ['selectedFacilities' => $facilities];

            case 'room_facilities':
                $roomFacilities = Facility::select('id', 'name')
                    ->whereIn('id', $indexData['selectedRoomFacility']['ids'])
                    ->get()
                    ->map(function($facility) {
                        return [
                            'id' => $facility->id,
                            'name' => $facility->name,
                        ];
                    })
                    ->toArray();
                    
                return ['selectedRoomFacilities' => $roomFacilities];
        }

        return [];
    }

    private function buildBaseQuery(?array $managerHotelIds): Builder
    {
        $builder = Hotel::with([
            'rooms' => function($query) {
                $query->select('id', 'hotel_id', 'price');
            },
            'rooms.facilities' => function($query) {
                $query->select('facilities.id', 'facilities.name');
            },
            'facilities' => function($query) {
                $query->select('facilities.id', 'facilities.name');
            }
        ]);

        if ($managerHotelIds) {
            $builder->whereIn('id', $managerHotelIds);
        }

        return $builder;
    }

    private function applyFilters(Builder $builder, array $indexData): void
    {
        // Фильтрация по цене и датам
        if (!isAdminPanel() || isset($indexData['filterByMinPrice']) || isset($indexData['filterByMaxPrice'])) {
            $this->applyPriceAndDateFilters($builder, $indexData);
        }
    }

    private function applyPriceAndDateFilters(Builder $builder, array $indexData): void
    {
        $min = $indexData['filterByMinPrice'] ?? null;
        $max = $indexData['filterByMaxPrice'] ?? null;
        $startDay = $indexData['startDate'] ?? null;
        $endDay = $indexData['endDate'] ?? null;

        $builder->whereHas('rooms', function (Builder $query) use ($min, $max, $startDay, $endDay) {
            // Фильтр по цене
            if (isset($min) && isset($max)) {
                $query->whereBetween('price', [$min, $max]);
            } elseif (isset($min)) {
                $query->where('price', '>=', $min);
            } elseif (isset($max)) {
                $query->where('price', '<=', $max);
            }

            // Фильтр по датам доступности
            if ($startDay || $endDay) {
                $query->where(function ($query) use ($startDay, $endDay) {
                    $query->whereHas('bookings', function (Builder $query) use ($startDay, $endDay) {
                        if ($startDay && $endDay) {
                            $query->where('started_at', '>=', $endDay)
                                  ->orWhere('finished_at', '<=', $startDay);
                        } elseif ($startDay) {
                            $query->where('finished_at', '<=', $startDay);
                        } elseif ($endDay) {
                            $query->where('started_at', '>=', $endDay);
                        }
                    });
                    $query->orDoesntHave('bookings');
                });
            }
        });
    }

    private function getFilterDataWithCache(Builder $builder, HelperController $helper): array
    {
        $cacheKey = 'hotels_filter_' . md5(serialize([
            $builder->getQuery()->wheres,
            $helper->backendIndexData['filters'] ?? []
        ]));

        return Cache::remember($cacheKey, self::CACHE_TTL, function () use ($builder, $helper) {
            return $this->calculateFilterData($builder, $helper);
        });
    }

    private function calculateFilterData(Builder $builder, HelperController $helper): array
    {
        // Используем более эффективный способ сбора данных
        $hotelsData = $builder->get()->map(function($hotel) {
            $roomFacilityIds = $hotel->rooms->flatMap(function($room) {
                return $room->facilities->pluck('id');
            })->unique()->values()->toArray();

            return [
                'id' => $hotel->id,
                'facilityId' => $hotel->facilities->pluck('id')->toArray(),
                'roomFacilityId' => $roomFacilityIds,
                'minPrice' => $hotel->rooms->min('price'),
                'maxPrice' => $hotel->rooms->max('price'),
            ];
        });

        $hotelsCollect = collect($hotelsData);

        // Словари для фильтров
        $dictionariesAll = $this->buildDictionaries($builder);

        $filterOptions = $this->getOptionsForFilters(
            $hotelsCollect, 
            $helper->backendIndexData['filters'] ?? null, 
            self::FILTERS_FORMAT
        );

        $filteredCollect = $this->filterCollection(
            $hotelsCollect, 
            $helper->backendIndexData['filters'] ?? null, 
            self::FILTERS_FORMAT
        );

        return [
            'filterOptions' => $filterOptions,
            'dictionaries' => $this->getFilterOptionsDictionaries(
                $filterOptions, 
                $dictionariesAll, 
                self::DICTIONARIES_FORMAT
            ),
            'minPrice' => $filteredCollect->min('minPrice'),
            'maxPrice' => $filteredCollect->max('maxPrice'),
            'hotelIds' => $filteredCollect->pluck('id')->toArray()
        ];
    }

    private function buildDictionaries(Builder $builder): array
    {
        // Используем один запрос для получения всех данных словарей
        $dictionaries = [
            'hotel' => [],
            'facility' => [],
            'roomFacility' => []
        ];

        $hotels = $builder->with(['facilities', 'rooms.facilities'])->get();

        foreach ($hotels as $hotel) {
            $dictionaries['hotel'][$hotel->id] = $hotel->name;
            
            foreach ($hotel->facilities as $facility) {
                $dictionaries['facility'][$facility->id] = $facility->name;
            }
            
            $roomFacilities = $hotel->rooms->flatMap(function($room) {
                return $room->facilities;
            })->unique('id');
            
            foreach ($roomFacilities as $facility) {
                $dictionaries['roomFacility'][$facility->id] = $facility->name;
            }
        }

        return $dictionaries;
    }

    private function getFinalResults(Builder $builder, HelperController $helper)
    {
        // Применяем финальные условия
        if (isset($this->filterData['hotelIds'])) {
            $builder->whereIn('id', $this->filterData['hotelIds']);
        }

        $builder->orderBy(
            $helper->backendIndexData['sort']['field'], 
            $helper->backendIndexData['sort']['order']
        );

        $hotels = $builder->paginate(6);

        // Добавляем информацию о ценах
        $hotels->getCollection()->transform(function($hotel) {
            $minPrice = $hotel->rooms->min('price');
            $maxPrice = $hotel->rooms->max('price');
            
            $hotel->price = ($minPrice === $maxPrice) 
                ? $minPrice 
                : $minPrice . '-' . $maxPrice;
                
            return $hotel;
        });

        return $hotels;
    }
}