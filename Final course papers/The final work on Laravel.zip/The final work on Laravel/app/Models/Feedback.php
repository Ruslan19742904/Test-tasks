<?php

namespace App\Models;

use App\Services\HotelRatingService;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Feedback extends Model
{
    use HasFactory;

    protected $table = 'feedbacks';
    protected $guarded = false;
    protected $with = ['user', 'hotel'];

    protected static function boot()
    {
        parent::boot();

        static::saved(function (Feedback $feedback) {
            if ($feedback->wasChanged('is_active')) {
                app(HotelRatingService::class)->updateRating($feedback->hotel);
            }
        });

        static::deleted(function (Feedback $feedback) {
            app(HotelRatingService::class)->updateRating($feedback->hotel);
        });
    }

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }

    public function hotel()
    {
        return $this->belongsTo(Hotel::class, 'hotel_id', 'id');
    }
}