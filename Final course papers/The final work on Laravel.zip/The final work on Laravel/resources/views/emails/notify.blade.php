<p>{!! $data['message'] !!}</p>
