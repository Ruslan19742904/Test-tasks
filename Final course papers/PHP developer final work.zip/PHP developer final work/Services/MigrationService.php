<?php

namespace App\Services;

use App\Core\DB;
use Exception;

class MigrationService extends BaseService
{
    public function startMigration(): void
    {
        $migrationsDir = __DIR__ . '/../Migrations';
        $files = scandir($migrationsDir);

        foreach ($files as $file) {
            if ($file === '.' || $file === '..') {
                continue;
            }

            $sql = file_get_contents($migrationsDir . '/' . $file);
            if ($sql === false) {
                throw new Exception('Ошибка чтения файла миграции: ' . $file);
            }

            DB::getInstance()->executeQuery($sql);
        }
    }
}