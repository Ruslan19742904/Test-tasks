<?php

namespace App\Services;

use App\Core\App;
use App\Core\Exceptions\ForbiddenException;
use App\Core\Exceptions\WrongRequestException;
use App\Models\Share;
use PDOException;

class ShareService extends BaseService
{
    public function showShare(array $params): string
    {
        $fileID = (int) $params['file_id'];
        $pageNum = (int) $params['page_num'];

        App::$security->checkFileOwner($fileID);

        $usersList = Share::getSharedUsers($fileID, $pageNum);

        return json_encode($usersList);
    }

    public function addShare(array $params): void
    {
        $fileID = (int) $params['file_id'];
        $memberID = (int) $params['member_id'];

        App::$security->checkFileOwner($fileID);

        if ($memberID === App::$userID) {
            throw new ForbiddenException('Невозможно предоставить совместный доступ самому себе');
        }

        try {
            Share::insert([
                'file_id' => $fileID,
                'member_id' => $memberID
            ]);
        } catch (PDOException $e) {
            if ($e->getCode() === '23000' && str_contains($e->getMessage(), 'check_file_member')) {
                throw new WrongRequestException('Совместный доступ уже предоставлен');
            }
            throw $e;
        }
    }

    public function deleteShare(array $params): void
    {
        $shareID = (int) $params['share_id'];
        App::$security->checkShareOwner($shareID);
        Share::delete(['share_id' => $shareID]);
    }
}