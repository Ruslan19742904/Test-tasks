<?php

namespace App\Services;

use App\Core\App;
use App\Core\Exceptions\WrongRequestException;
use App\Models\User;
use PDOException;

class AdminService extends BaseService
{
    public function showUser(array $params): string
    {
        if (isset($params['user_id'])) {
            $result = User::selectRowBy(
                ['user_id' => (int)$params['user_id']],
                ['login', 'password', 'role', 'nickname', 'phone']
            );
            if (!$result) {
                throw new WrongRequestException('Пользователь с указанным ID не найден');
            }
            return json_encode($result);
        } else {
            $users = User::selectAllRows(
                (int)$params['page_num'],
                ['user_id', 'login', 'password', 'role', 'nickname', 'phone']
            );
            return json_encode($users);
        }
    }

    public function addUser(array $params): void
    {
        if (!filter_var($params['login'], FILTER_VALIDATE_EMAIL)) {
            throw new WrongRequestException('В качестве логина необходимо указать e-mail');
        }

        try {
            User::insert($params);
        } catch (PDOException $e) {
            if ($e->getCode() === '23000') {
                throw new WrongRequestException('Пользователь уже существует');
            }
            throw $e;
        }
    }

    public function editUser(array $params): void
    {
        $userID = (int) $params['user_id'];
        unset($params['user_id']);

        $affected = User::update($params, ['user_id' => $userID]);
        if ($affected === 0) {
            throw new WrongRequestException('Пользователь с указанным ID не найден');
        }
    }

    public function deleteUser(array $params): void
    {
        $userID = (int) $params['user_id'];

        if ($userID === App::$userID) {
            throw new WrongRequestException('Невозможно удалить свою учётную запись');
        }

        $affected = User::delete(['user_id' => $userID]);
        if ($affected === 0) {
            throw new WrongRequestException('Пользователь с указанным ID не найден');
        }
    }
}