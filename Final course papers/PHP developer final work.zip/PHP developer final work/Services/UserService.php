<?php

namespace App\Services;

use App\Core\App;
use App\Core\Exceptions\WrongRequestException;
use App\Models\User;

class UserService extends BaseService
{
    public function showUser(array $params): string
    {
        if (isset($params['user_id'])) {
            $result = User::selectRowBy(['user_id' => (int)$params['user_id']], ['user_id', 'nickname', 'phone']);
            if (!$result) {
                throw new WrongRequestException('Пользователь с указанным ID не найден');
            }
            return json_encode($result);
        } else {
            $users = User::selectAllRows((int)$params['page_num'], ['user_id', 'nickname', 'phone']);
            return json_encode($users);
        }
    }

    public function editUser(array $params): void
    {
        User::update($params, ['user_id' => App::$userID]);
    }
}