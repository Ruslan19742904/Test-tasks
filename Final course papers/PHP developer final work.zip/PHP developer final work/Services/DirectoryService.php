<?php

namespace App\Services;

use App\Core\App;
use App\Core\Exceptions\WrongRequestException;
use App\Models\File;
use PDOException;

class DirectoryService extends BaseService
{
    const GLOBAL_ROOT_DIR = 1;
    const SHARED_TO_ME = 'shared_to_me';
    const SHARED_FROM_ME = 'shared_from_me';

    private function checkDirectoryName(string $directoryName): void
    {
        if (mb_strlen($directoryName) > 255 || preg_match('/[\/:*?"<>|\\\\]/', $directoryName)) {
            throw new WrongRequestException('Недопустимое имя папки');
        }
    }

    public function showDir(array $params): string
    {
        $directoryID = $params['directory_id'];
        $pageNum = (int) $params['page_num'];

        if ($directoryID === self::SHARED_TO_ME) {
            $filesList = File::getSharedToMe(App::$userID, $pageNum);
        } elseif ($directoryID === self::SHARED_FROM_ME) {
            $filesList = File::getSharedFromMe(App::$userID, $pageNum);
        } else {
            $directoryID = (int) $directoryID;
            App::$security->checkDirectoryOwner($directoryID);

            $filesList = File::getDirectoryContents($directoryID, App::$userID, $pageNum);

            if ($directoryID !== self::GLOBAL_ROOT_DIR) {
                $parentId = File::getParentId($directoryID);
                if ($parentId !== null) {
                    $filesList[] = [
                        'file_id' => $parentId,
                        'is_dir' => 1,
                        'original_file_name' => '..',
                        'loading_time' => null
                    ];
                }
            }
        }

        return json_encode($filesList);
    }

    public function addDir(array $params): void
    {
        $parentID = (int) $params['parent_id'];
        $directoryName = $params['directory_name'];

        App::$security->checkDirectoryOwner($parentID);
        $this->checkDirectoryName($directoryName);

        try {
            File::insert([
                'parent_id' => $parentID,
                'is_dir' => 1,
                'owner_id' => App::$userID,
                'original_file_name' => $directoryName
            ]);
        } catch (PDOException $e) {
            if ($e->getCode() === '23000' && str_contains($e->getMessage(), 'check_file_duplicate')) {
                throw new WrongRequestException('Папка уже существует');
            }
            throw $e;
        }
    }

    public function editDir(array $params): void
    {
        $directoryID = (int) $params['directory_id'];
        $directoryName = $params['directory_name'];

        if ($directoryID === self::GLOBAL_ROOT_DIR) {
            throw new WrongRequestException('Невозможно изменить корневую папку');
        }

        App::$security->checkDirectoryOwner($directoryID);
        $this->checkDirectoryName($directoryName);

        try {
            File::update(
                ['original_file_name' => $directoryName],
                ['file_id' => $directoryID]
            );
        } catch (PDOException $e) {
            if ($e->getCode() === '23000' && str_contains($e->getMessage(), 'check_file_duplicate')) {
                throw new WrongRequestException('Папка уже существует');
            }
            throw $e;
        }
    }

    public function deleteDir(array $params): void
    {
        $directoryID = (int) $params['directory_id'];

        if ($directoryID === self::GLOBAL_ROOT_DIR) {
            throw new WrongRequestException('Невозможно удалить корневую папку');
        }

        App::$security->checkDirectoryOwner($directoryID);

        try {
            File::delete(['file_id' => $directoryID]);
        } catch (PDOException $e) {
            if ($e->getCode() === '23000' && str_contains($e->getMessage(), 'check_parent')) {
                throw new WrongRequestException('Папка должна быть пустой');
            }
            throw $e;
        }
    }
}