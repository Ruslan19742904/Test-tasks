<?php

namespace App\Services;

use App\Core\App;
use App\Core\Config\Config;
use App\Core\Exceptions\ForbiddenException;
use App\Core\Exceptions\WrongRequestException;
use App\Models\File;
use App\Models\Share;
use PDOException;
use Ramsey\Uuid\Uuid;

class FileService extends BaseService
{
    private function includeTrailingDelimiter(string $path): string
    {
        if (!str_ends_with($path, '/')) {
            $path .= '/';
        }
        return $path;
    }

    private function getStoragePath(): string
    {
        $config = new Config();
        return $this->includeTrailingDelimiter($config->configParam('storage_path'));
    }

    private function checkFileName(string $fileName): void
    {
        if (mb_strlen($fileName) > 255 || preg_match('/[\/:*?"<>|\\\\]/', $fileName)) {
            throw new WrongRequestException('Недопустимое имя файла');
        }
    }

    public function downloadFile(array $params): void
    {
        $fileID = (int) $params['file_id'];

        $result = File::findById($fileID, ['is_dir', 'owner_id', 'file_name', 'original_file_name']);
        if (!$result || $result['is_dir'] == 1) {
            throw new WrongRequestException('Неверно указан ID файла');
        }

        if ($result['owner_id'] != App::$userID) {
            $shared = Share::selectRowBy([
                'file_id' => $fileID,
                'member_id' => App::$userID
            ], ['1']);
            if (!$shared) {
                throw new ForbiddenException('Нет прав доступа к указанному файлу');
            }
        }

        $fileName = $result['file_name'];
        $originalFileName = $result['original_file_name'];

        header('Content-Description: File Transfer');
        header('Content-Disposition: attachment; filename=' . basename($originalFileName));
        header('Content-Type: ' . mime_content_type($this->getStoragePath() . $fileName));
        header('Cache-Control: must-revalidate');
        readfile($this->getStoragePath() . $fileName);
    }

    public function uploadFile(array $params): void
    {
        $directoryID = (int) $params['directory_id'];
        App::$security->checkDirectoryOwner($directoryID);

        if (!isset($_FILES['file']['name'])) {
            throw new WrongRequestException('Не отправлен файл');
        }
        if ($_FILES['file']['size'] > 2 * 1024 * 1024 * 1024) {
            throw new WrongRequestException('Размер файла превышает 2 Гб');
        }

        $originalFileName = $_FILES['file']['name'];
        $extension = pathinfo($originalFileName, PATHINFO_EXTENSION);
        $storageFileName = Uuid::uuid4()->toString() . '.' . strtolower($extension);

        $storagePath = $this->getStoragePath();
        $fullPath = $storagePath . $storageFileName;

        if (!move_uploaded_file($_FILES['file']['tmp_name'], $fullPath)) {
            throw new WrongRequestException('Не удалось сохранить файл на сервере');
        }

        try {
            File::insert([
                'parent_id' => $directoryID,
                'is_dir' => 0,
                'owner_id' => App::$userID,
                'original_file_name' => $originalFileName,
                'file_name' => $storageFileName
            ]);
        } catch (PDOException $e) {
            if (file_exists($fullPath)) {
                unlink($fullPath);
            }

            if ($e->getCode() === '23000') {
                if (str_contains($e->getMessage(), 'check_file_duplicate')) {
                    throw new WrongRequestException('Файл уже загружен');
                } elseif (str_contains($e->getMessage(), 'check_parent')) {
                    throw new WrongRequestException('Неверно указан ID папки');
                }
            }
            throw $e;
        }
    }

    public function editFile(array $params): void
    {
        $fileID = (int) $params['file_id'];
        $fileName = $params['file_name'];

        App::$security->checkFileOwner($fileID);
        $this->checkFileName($fileName);

        try {
            File::update(
                ['original_file_name' => $fileName],
                ['file_id' => $fileID]
            );
        } catch (PDOException $e) {
            if ($e->getCode() === '23000' && str_contains($e->getMessage(), 'check_file_duplicate')) {
                throw new WrongRequestException('Файл с таким именем уже существует');
            }
            throw $e;
        }
    }

    public function deleteFile(array $params): void
    {
        $fileID = (int) $params['file_id'];
        $fileName = App::$security->checkFileOwner($fileID); 

        File::delete(['file_id' => $fileID]);

        $fullPath = $this->getStoragePath() . $fileName;
        if (file_exists($fullPath)) {
            unlink($fullPath);
        }
    }
}