<?php

namespace App\Models;

use App\Core\DB;

abstract class Model
{
    protected static string $table;
    protected static array $fillable = [];

    public static function selectRowBy(array $conditions, array $columns = ['*']): ?array
    {
        return DB::getInstance()->selectRowBy(static::$table, $columns, $conditions);
    }

    public static function selectAllRows(int $page = 1, array $columns = ['*']): array
    {
        return DB::getInstance()->selectAllRows(static::$table, $columns, $page);
    }

    public static function selectRowsBy(array $conditions, int $page = 1, array $columns = ['*']): array
    {
        return DB::getInstance()->selectRowsBy(static::$table, $columns, $conditions, $page);
    }

    public static function insert(array $data): void
    {
        $filtered = array_intersect_key($data, array_flip(static::$fillable));
        DB::getInstance()->insertRow(static::$table, $filtered);
    }

    public static function update(array $data, array $conditions): int
    {
        $filtered = array_intersect_key($data, array_flip(static::$fillable));
        return DB::getInstance()->updateRows(static::$table, $filtered, $conditions);
    }

    public static function delete(array $conditions): int
    {
        return DB::getInstance()->deleteRows(static::$table, $conditions);
    }
}