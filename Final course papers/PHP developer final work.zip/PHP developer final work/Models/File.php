<?php

namespace App\Models;

class File extends Model
{
    protected static string $table = 'files_list';
    protected static array $fillable = [
        'parent_id',
        'is_dir',
        'owner_id',
        'original_file_name',
        'file_name'
    ];

    public static function findById(int $fileId, array $columns = ['*']): ?array
    {
        return self::selectRowBy(['file_id' => $fileId], $columns);
    }

    public static function existsDuplicate(int $parentId, int $ownerId, string $originalFileName): bool
    {
        $result = self::selectRowBy([
            'parent_id' => $parentId,
            'owner_id' => $ownerId,
            'original_file_name' => $originalFileName
        ], ['file_id']);
        return $result !== null;
    }

        
    /**
     * Получает содержимое папки (файлы и подпапки) пользователя
     */
    public static function getDirectoryContents(int $directoryId, int $ownerId, int $page = 1): array
    {
        return self::selectRowsBy([
            'parent_id' => $directoryId,
            'owner_id' => $ownerId
        ], $page, ['file_id', 'is_dir', 'original_file_name', 'loading_time']);
    }

    /**
     * Получает родительский ID папки
     */
    public static function getParentId(int $fileId): ?int
    {
        $row = self::selectRowBy(['file_id' => $fileId], ['parent_id']);
        return $row ? (int)$row['parent_id'] : null;
    }

    /**
     * Получает файлы, расшаренные пользователю (shared_to_me)
     */
    public static function getSharedToMe(int $userId, int $page = 1): array
    {
        // Используем тот же JOIN, что и раньше
        return DB::getInstance()->selectRowsBy(
            'files_list f join shares_list s on f.file_id = s.file_id',
            ['f.file_id', 'is_dir', 'original_file_name', 'loading_time'],
            ['member_id' => $userId],
            $page
        );
    }

    /**
     * Получает файлы, расшаренные пользователем (shared_from_me)
     */
    public static function getSharedFromMe(int $ownerId, int $page = 1): array
    {
        return DB::getInstance()->selectRowsBy(
            'files_list f join shares_list s on f.file_id = s.file_id',
            ['f.file_id', 'original_file_name', 'loading_time'],
            ['owner_id' => $ownerId],
            $page
        );
    }
}