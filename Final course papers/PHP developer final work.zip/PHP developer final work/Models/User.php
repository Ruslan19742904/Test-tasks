<?php

namespace App\Models;

class User extends Model
{
    protected static string $table = 'users';
    protected static array $fillable = [
        'login',
        'password',
        'role',
        'nickname',
        'phone',
        'reset_token',
        'auth_token'
    ];
}