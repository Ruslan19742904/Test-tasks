<?php

namespace App\Models;

use App\Core\DB;

class Share extends Model
{
    protected static string $table = 'shares_list';
    protected static array $fillable = ['file_id', 'member_id'];

    public static function getSharedUsers(int $fileId, int $page = 1): array
    {
        return DB::getInstance()->selectRowsBy(
            'shares_list join users on member_id = user_id',
            ['user_id', 'login', 'nickname'],
            ['file_id' => $fileId],
            $page
        );
    }
}